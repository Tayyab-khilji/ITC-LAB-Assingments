#include <iostream>
using namespace std;
int main()
{
	int Number;
	cout << "Please enter a number "; 
	cin >> Number;
	cout << Number * 1 << ",";
	cout << Number * 2 << ",";
	cout << Number * 3 << ",";
	cout << Number * 4 << ",";
	cout << Number * 5 << ",";
	return 0;
}
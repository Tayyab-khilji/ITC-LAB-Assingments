#include <iostream>
using namespace std;
int main()
{
	int num;
	cout << "Please enter a number = ";
	cin >> num;
	if (num > 0){
		cout << endl << num << " is positive" << endl;
	}
	else{
		cout << num << " is negative" << endl;
	}
	return 0;

}





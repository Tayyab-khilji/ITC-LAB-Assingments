#include<iostream>
using namespace std;
int main(){
	
    cout << "   *   "\n;
    cout << "  * *  ";
    cout << " *   *  ";
    cout << "*******";

	return 0;
}
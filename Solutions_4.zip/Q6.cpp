#include<iostream>
using namespace std;
int main(){
	
    cout << "Name: Tayyab Rehman\n";
    cout << "Contact: 03**********\n";
    cout << "Email: tayyab@mail.com\n";
    cout << "Age: 18\n";
    cout << "Gender: Male\n";
    cout << "Faculty: FOIT\n";
    cout << "Department: SE\n";
    cout << "Program: BSSE\n";
    cout << "Courses: \n";
    cout << "ITC\n";
    cout << "BE\n";
    cout << "ISL\n";
    cout << "ENG\n";
    cout << "PAK-STD\n";

	return 0;
}
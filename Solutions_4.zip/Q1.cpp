#include<iostream>
using namespace std;
int main(){
	cout << "************";
	cout << "Hello World!";
    cout << "************";
	return 0;
}
#include<iostream>
using namespace std;
int main(){

	cout << "Hey Students.Solve me and get your deserved Marks ^_^";
	cout << "Good Luck!";
	cout << "I hope you all are working really hard to achieve best of the results!";
	return 0;
}
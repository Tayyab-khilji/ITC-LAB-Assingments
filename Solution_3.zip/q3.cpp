#include<iostream>
using namespace std;
	int main()
	{
		cout << "13 x 1 = " << 13 * 1 << endl;
		cout << "13 x 2 = " << 13 * 2 << endl;
		cout << "13 x 3 = " << 13 * 3 << endl;
		cout << "13 x 4 = " << 13 * 4 << endl;
		cout << "13 x 5 = " << 13 * 5 << endl;
		cout << "13 x 6 = " << 13 * 6 << endl;
		cout << "13 x 7 = " << 13 * 7 << endl;
		cout << "13 x 8 = " << 13 * 8 << endl;
		cout << "13 x 9 = " << 13 * 9 << endl;
		cout << "13 x 10 = " << 13 * 10 << endl;
		cout << "13 x 11 = " << 13 * 11 << endl;
		cout << "13 x 12 = " << 13 * 12 << endl;
		cout << "13 x 13 = " << 13 * 13 << endl;
		cout << "13 x 14 = " << 13 * 14 << endl;
		cout << "13 x 15 = " << 13 * 15 << endl;
	return 0;
}

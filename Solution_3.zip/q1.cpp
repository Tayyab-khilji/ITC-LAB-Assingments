#include<iostream>
using namespace std;
int main(){

	cout << "My name is\n";
	cout << "          tayyab, and I want to learn\n";
	cout << "                                     ITC\n";
	return 0;
}
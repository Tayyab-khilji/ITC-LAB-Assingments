#include<iostream>
using namespace std;
int main(){
	cout << "*\n";
	cout << "* *\n";
	cout << "* * *\n";
	cout << "* * * *\n";
	cout << "* * * * *\n";
	cout << "* * * * * * *\n";
	cout << "\n";
	cout << "Half Pyramid\n";
	cout << "\n";
	// Half Pyramid
	cout << "* * * * * * *\n";
	cout << "* * * * *\n";
	cout << "* * * *\n";
	cout << "* * *\n";
	cout << "* *\n";
	cout << "*\n";
	cout << "\n";
	cout << "Inverted Half Pyramid\n";
	cout << "\n";
	// Inverted Half 
	cout << "* * * * * *\n";
	cout << "*       *\n";
	cout << "*     *\n";
	cout << "*   *\n";
	cout << "* *\n";
	cout << "*\n";
	cout << "\n";
	cout << "Hollow Inverted Half Pyramid\n";
	cout << "\n";
	// hollow Inverted pyramid
	cout << "     *     \n";
	cout << "    * *    \n";
	cout << "   * * *   \n";
	cout << "  * * * *  \n";
	cout << " * * * * * \n";
	cout << "* * * * * *\n";
	cout << "\n";
	cout << "Full Pyramid\n";
	cout << "\n";
	// Full pyramid
	cout << "* * * * * *\n";
	cout << " * * * * * \n";
	cout << "  * * * *  \n";
	cout << "   * * *   \n";
	cout << "    * *    \n";
	cout << "     *     \n";
	cout << "\n";
	cout << "Full inverted Pyramid\n";
	cout << "\n";
	// Inverted Full pyramid
	cout << "* * * * * *\n";
	cout << " *       * \n";
	cout << "  *     *  \n";
	cout << "   *   *   \n";
	cout << "    * *    \n";
	cout << "     *     \n";
	cout << "\n";
	cout << "Full inverted Hollow Pyramid\n";
	cout << "\n";
	// Inverted Full Hollow pyramid
	return 0;
}
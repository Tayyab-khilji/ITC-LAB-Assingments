#include<iostream>
using namespace std;
	int main()
	{
		int num = 13;
		cout << "num x 5 = " << num * 5 << endl;
		cout << "num x 6 = " << num * 6 << endl;
		cout << "num x 7 = " << num * 7 << endl;
		cout << "num x 8 = " << num * 8 << endl;
		cout << "num x 9 = " << num * 9 << endl;
		cout << "num x 10 = " << num * 10 << endl;
		cout << "num x 11 = " << num * 11 << endl;
		cout << "num x 12 = " << num * 12 << endl;
		cout << "num x 13 = " << num * 13 << endl;
		cout << "num x 14 = " << num * 14 << endl;
		cout << "num x 15 = " << num * 15 << endl;
		cout << "num x 16 = " << num * 16 << endl;
		cout << "num x 17 = " << num * 17 << endl;
		cout << "num x 18 = " << num * 18 << endl;
		cout << "num x 19 = " << num * 19 << endl;
		cout << "num x 20 = " << num * 20 << endl;
	return 0;
}
